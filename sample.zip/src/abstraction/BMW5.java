package abstraction;

public class BMW5 extends BMW{
	@Override
	void accelarate() {
		System.out.println("Five series accelarate method");
	}

}
