package FullAbstraction;

public interface car { //full abstraction needs interface
	void go();

	void stop();

}
