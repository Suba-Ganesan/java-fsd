package FullAbstraction;

public class honda implements car{
	
		@Override
		public void go() {
			System.out.println("Inside Honda Go");
		}

		@Override
		public void stop() {
			System.out.println("Inside Honda Stop");
		}


}
