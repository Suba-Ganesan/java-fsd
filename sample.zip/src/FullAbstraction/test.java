package FullAbstraction;

public class test {
	public static void main(String[] args) {
//		Car honda = new Honda();
//		honda.go();
//		honda.stop();
//		
//		Car toyota = new Toyota();
//		toyota.go();
//		toyota.stop();
		
		car car = new toyota();
		car.go();
		car.stop();
	}

}
