package abstraction;

public abstract class BMW {
	void commonFunctionality() {
		System.out.println("Inside common functionality method");
	}
	
	abstract void accelarate();
}
