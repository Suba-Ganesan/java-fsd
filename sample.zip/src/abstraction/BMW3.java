package abstraction;

public class BMW3 extends BMW {

//	@Override
	void accelarate() {
		System.out.println("BMW3 Series accelarate");
	}
}
